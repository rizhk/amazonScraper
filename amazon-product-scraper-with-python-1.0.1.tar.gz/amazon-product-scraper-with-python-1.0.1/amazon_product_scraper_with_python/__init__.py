from bot_studio import *
amazon=bot_studio.amazon()